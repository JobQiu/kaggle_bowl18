There are couple of things that will make the processing of your issue faster:
1. Use labels to categorize your issue,
2. Make sure that you are using the latest version of the master branch of data-science-bowl-2018,
3. In case it is a bug issue, it would be nice to provide more technical details or python script that reproduces your error.

Thanks!

Neptune's ml-team
