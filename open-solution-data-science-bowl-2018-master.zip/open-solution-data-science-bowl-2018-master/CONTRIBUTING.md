# Contributing to the data-science-bowl-2018

Here, at [neptune.ml](https://neptune.ml/) we are creating an open solution to the [Data Science Bowl](https://datasciencebowl.com/). Hence, you are very welcome to contribute you piece to this solution.

You can do it in two main ways:
1. Major - and most appreciated - way is to submit pull request with bug fix or additional feature. Your pull request will be merged after some discussion.
2. Submit an issue with appropriate label (bug, feature request or question).

Finally, in case of custom ideas, contact neptune's ml-team directly at ml-team@neptune.ml.
